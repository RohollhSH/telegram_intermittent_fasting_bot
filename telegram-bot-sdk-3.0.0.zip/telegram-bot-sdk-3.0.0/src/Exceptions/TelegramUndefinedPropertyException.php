<?php

namespace Telegram\Bot\Exceptions;

/**
 * Class TelegramUndefinedPropertyException.
 */
class TelegramUndefinedPropertyException extends \Exception
{
}
