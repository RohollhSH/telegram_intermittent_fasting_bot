<?php

namespace Telegram\Bot\Exceptions;

/**
 * Class TelegramOtherException.
 */
class TelegramEmojiMapFileNotFoundException extends TelegramSDKException
{
}
